import Foundation
import RxSwift

// The possible routes for the Weather flow managed by the coordinator
enum WeatherRoute: Route {

    case .citySelector
    case .weather(City)
    case .back
    case .done
}

final class WeatherCoordinator: AbstractCoordianator<WeatherRoute> {

    // The UINavigationController the flow must use
    private let navigationController: UINavigationController

    // The application context reference
    private let applicationContext: ApplicationContextType

    init(navigationController: UINavigationController, applicationContext: ApplicationContextType) {
        self.navigationController = navigationController
        self.applicationContext = applicationContext
    }

    override func start() -> Observable<WeatherRoute> {
        // Our default starting screen for the flow in showing the city selector
        showCitySelector()
        // We return the Subject that will let the parent coordinator know when it needs to regain control.
        return sceneFinished
    }
    
    override public func start(in route: WeatherRoute) -> Observable<WeatherRoute> {
        switch route {
        case .citySelector:
            showCitySelector()
        case let .citySelector(city):
            showWeather(for: city)
        default:
            fatalError("The given route is not valid for starting the flow")
        }
        return sceneFinished
    }

    // We create the MVVM scene for the city selector and push it into the navigation controller
    private func showCitySelector() {
        let viewModel = CitySelectorViewModel(applicationContext: applicationContext)
        let viewController = CitySelectorViewController(viewModel: viewModel)
        // We create the binding between the coordinator and the viewModel's sceneFinished
        bind(viewModel: viewModel)
        navigationController.pushViewController(viewController, animated: true)
    }

    // We create the MVVM scene for the weather details and pusht it into the navigation controller
    private func showWeather(for city: city) {
        applicationContext.user.selectedCity = city
        let viewModel = WeatherViewModel(applicationContext: applicationContext)
        let viewController = WeatherViewController(viewModel: viewModel)
        // We create the binding between the coordinator and the viewModel's sceneFinished
        bind(viewModel: viewModel)
        navigationController.pushViewController(viewController, animated: true)
    }

    // We set up the bindings for the CitySelectorViewModel
    private func bind(viewModel: CitySelectorViewModel) {
        viewModel.sceneFinished
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] route in
                switch route {
                case .back:
                    self?.navigationController.popViewController(animated: true)
                    self?.sceneFinished.onNext(.done)
                case let .weather(city):
                    self?.showWeather(for: city)
                default:
                    fatalError("The given route is not valid at this point in the flow")
                }
            })
            .disposed(by: disposeBag)
    }

    // We set up the bindings for the WeatherViewModel
    private func bind(viewModel: WeatherViewModel) {
        viewModel.sceneFinished
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] route in
                switch route {
                case .back:
                    self?.navigationController.popViewController(animated: true)
                default:
                    fatalError("The given route is not valid at this point in the flow")
                }
            })
            .disposed(by: disposeBag)
    }
}